# i3ipc-python Examples

You can contribute examples by adding your python scripts to this folder. If your script is useful, someone might help you improve and maintain it. You can also request a new script by [posting a script request](https://github.com/acrisci/i3ipc-python/issues) on the issue tracker.
